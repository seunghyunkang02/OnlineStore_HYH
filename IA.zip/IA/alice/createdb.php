<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Create Table</title>
</head>

<body>
<?php
$servername = "localhost";
$username = "id10006022_alice";
$password = "password12345";
$dbname = "id10006022_hanyinhong";
$tbl = "customertbl";
$tbl2 = "producttbl";
	
//create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

//check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
} 
	
//creat table
$sql2 = "CREATE TABLE $tbl2 (
    productID INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    productName varchar(100),
    originalPrice int(25),
    quantity int(25)
	description varchar(200),
	productimage varchar(100)
)
";	

//add data
$sql2 = "INSERT INTO $tbl2 
	VALUES 
	(1,'Kimchi','16','100','a spicy pickled or fermented mixture containing cabbage, onions, and sometimes fish, variously seasoned, as with garlic, horseradish, red peppers, and ginger.','kimchi.png'),
	(2,'Kimchi Fried Rice','15','100','Kimchi fried rice is made primarily with kimchi and rice, along with other available ingredients, such as diced vegetables or meats like spam.','kimchifried.png'),
	(3,'Korean Dumpling(Steamed)','25','100','Authentic Korean Dumplings, comes in a pack of 360g Steamed Dumplings','mandusteam.png'),
	(4,'Korean Dumpling(Water/Boiled)','25','100','Authentic Korean Dumplings, comes in a pack of 350g of Boiled Dumplings','boiledmandu.png'),
	(5,'Korean Spicy Rice Cake','14','100','Spicy stir-fried rice cakes, is a highly popular Korean street food and a delicious comfort food you can easily make at home.','ricecake.png'),
	(6,'Honey Butter Almond','8','100','Honey butter almond snack shipped directly from Korea.','honeybutter.png'),
	(7,'Dry Sweet Potato','9','100','Dry sweet potato chips, all new sweet and savoury snack shipped directly from Korea.','drysweetpotato.png')
";

// close the connection to the database.
mysqli_close($conn);
?>

</body>
</html>