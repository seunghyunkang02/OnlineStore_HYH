<?php
session_start();
$server= 'localhost';
$username = 'root';
$password = 'password123';
$database = 'alice';
//create connection
$conn = mysqli_connect($servername, $username, $password, $database);

//check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";

//add pages for shopping cart system to redirect
$pages = array('cart', 'home', 'product', 'products', 'placeorder');
//setting a landing page, in this case home
$page = isset($_GET['page']) && in_array($_GET['page'], $pages) ? $_GET['page'] : 'home';
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>hanyinhong</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
        <header>
                <h1>hanyinhong</h1>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="index.php?page=products">Products</a>
                </nav>
                    <a href="index.php?page=cart"></a>
        </header>
        <main>
        <?php include $page . '.php'; ?>
        </main>
    </body>
</html>